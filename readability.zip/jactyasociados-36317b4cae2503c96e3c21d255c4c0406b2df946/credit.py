from cs50 import get_string
from math import floor

Amex1 = "34"
Amex2 = "37"
Mcard1 = "51"
Mcard2 = "52"
Mcard3 = "53"
Mcard4 = "54"
Mcard5 = "55"
Visa = "4"
brand = "INVALID"

# get input from the user
card = get_string("Card number: ")
card = card.strip()
count = len(card)

# compare first 2 digits to identify card brand
if count == 13:
    if card[:1] == Visa:
        brand = "VISA"

elif count == 15:
    if card[:2] == Amex1 or card[:2] == Amex2:
        brand = "AMEX"

elif count == 16:
    if card[:2] == Mcard1 or card[:2] == Mcard2 or card[:2] == Mcard3 or card[:2] == Mcard4 or card[:2] == Mcard5:
        brand = "MASTERCARD"

    elif card[:1] == Visa:
        brand = "VISA"

# luhn's algorithm for valid card number
if brand != "INVALID":
    card = int(card)
    last = 0
    tmp = 0
    secToLast = 0

    # sum odd and even numbers
    while card > 0:
        last += card % 10

        # first even number from the end eliminating last digit
        card /= 10
        card = floor(card)

        tmp = (card % 10) * 2

        # if the even number * 2 is 10 or bigger it add to odd numbers
        if tmp >= 10:
            secToLast += tmp % 10
            tmp /= 10
            secToLast += floor(tmp)

        # if the even number * 2 is 9 or less add it to the rest
        else:
            secToLast += tmp

        card /= 10
        card = floor(card)

    # validate algorithm and prints brand
    if (last + secToLast) % 10 == 0:
        print(brand)

    # print invalid if card digits not in range
    else:
        print("INVALID")


else:
    print(brand)
