from cs50 import get_string
import math

# gets user input about the text
text = get_string("Text: \n")

letters = 0.00
words = 0.00
sentence = 0.00
i = 0

while i < len(text):
    # count letters using ascii code
    if text[i] >= 'A' and text[i] <= 'z':
        letters += 1
    # count words separated by spaces excluding exclamations, interrogations and dots
    elif text[i] == ' ' and (text[i - 1] != '!' and text[i - 1] != '.' and text[i - 1] != '?'):
        words += 1
    # count sentences by exclamations, interrogations and dots
    elif text[i] == '!' or text[i] == '.' or text[i] == '?':
        sentence += 1
        words += 1
    i += 1
		
L = letters * 100 / words
S = sentence * 100 / words
# Coleman-Liau index fomula
index = round(0.0588 * L - 0.296 * S - 15.8)

# output result to the user
if index < 1:
    print("Before Grade 1\n")
elif index >= 16:
    print("Grade 16+\n")
else:
    print("Grade\n", index)
