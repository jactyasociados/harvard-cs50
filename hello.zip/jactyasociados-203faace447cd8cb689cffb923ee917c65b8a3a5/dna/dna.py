from csv import reader, DictReader
from sys import argv

if len(argv) < 3:
    print("usage error, dna.py database.csv sequence.txt")
    exit()

# read dna sequence from seqence.txt
with open(argv[2]) as dnasequence:
    dnasequencereader = reader(dnasequence)
    for row in dnasequencereader:
        dnasequencelist = row

# store dna sequence list as a string
dna = dnasequencelist[0]
# dictionary to store the dna database sequences to be counted
dnadatabasesequences = {}

# dna database sequences to list
with open(argv[1]) as dnadatabase:
    people = reader(dnadatabase)
    for row in people:
        dnasequencesrow = row
        dnasequencesrow.pop(0)
        break

# copy dns sequences into list
for item in dnasequencesrow:
    dnadatabasesequences[item] = 1

# count dna sequences repetitions
for key in dnadatabasesequences:
    lnght = len(key)
    counterMax = 0
    counter = 0
    for i in range(len(dna)):
        # skip counted sequences
        while counter > 0:
            counter -= 1
            continue

        # count dna sequences repetitions
        if dna[i: i + lnght] == key:
            while dna[i - lnght: i] == dna[i: i + lnght]:
                counter += 1
                i += lnght

            # if there is a sequence previously read larger then set counter to that sequence
            if counter > counterMax:
                counterMax = counter

    # longest dna database sequences into dictionary
    dnadatabasesequences[key] += counterMax

# iterate over people in the dna dictionary database printing not match if is not in
with open(argv[1], newline='') as dnadatabase:
    people = DictReader(dnadatabase)
    for person in people:
        match = 0
        # compares dna database sequences to check fo a match
        for dna in dnadatabasesequences:
            if dnadatabasesequences[dna] == int(person[dna]):
                match += 1
        if match == len(dnadatabasesequences):
            print(person['name'])
            exit()

    print("No match")
