#include "helpers.h"
#include <stdio.h>
#include <math.h>

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            //for some reason i'm still getting a stupid rounding issue here...............................
            float average = image[i][j].rgbtBlue + image[i][j].rgbtGreen + image[i][j].rgbtRed;
            average = average / 3;
            int rounded = rintf(average);
            image[i][j].rgbtBlue = roundf(rounded);
            image[i][j].rgbtGreen = roundf(rounded);
            image[i][j].rgbtRed = roundf(rounded);
        }

    }

    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE swap;
    if (width % 2 != 0)
    {
        for (int i = 0; i < height; i++)
        {
            // printf("[i][0]Before: %i\n[i][width]Before: %i\n", image[i][0].rgbtRed, image[i][width - 1].rgbtRed);
            swap = image[i][0];
            image[i][0] = image[i][width - 1];
            image[i][width - 1] = swap;
            // printf("[i][0]After: %i\n[i][width]After: %i\n", image[i][0].rgbtRed, image[i][width - 1].rgbtRed);
            for (int j = 1; j < ((width / 2)  + 0.5); j++)
            {
                swap = image[i][j];
                image[i][j] = image[i][(width - 1) - j];
                image[i][(width - 1) - j] = swap;
            }
        }
    }
    else
    {
        for (int i = 0; i < height; i++)
        {
            // printf("[i][0]Before: %i\n[i][width]Before: %i\n", image[i][0].rgbtRed, image[i][width - 1].rgbtRed);
            swap = image[i][0];
            image[i][0] = image[i][width - 1];
            image[i][width - 1] = swap;
            // printf("[i][0]After: %i\n[i][width]After: %i\n", image[i][0].rgbtRed, image[i][width - 1].rgbtRed);
            for (int j = 1; j < (width / 2); j++)
            {
                swap = image[i][j];
                image[i][j] = image[i][(width - 1) - j];
                image[i][(width - 1) - j] = swap;
            }
        }
    }

    return;

}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    typedef struct
    {
        int Red;
        int Blue;
        int Green;
    }
    temp;
    temp image2[height][width];

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            float averageR = image[i][j].rgbtRed;
            float averageG = image[i][j].rgbtGreen;
            float averageB = image[i][j].rgbtBlue;
            int counter = 1;

            // 7
            if (i != 0)
            {
                averageR += image[i - 1][j].rgbtRed;
                averageB += image[i - 1][j].rgbtBlue;
                averageG += image[i - 1][j].rgbtGreen;
                counter++;
            }
            //4
            if (j != 0)
            {
                averageR += image[i][j - 1].rgbtRed;
                averageB += image[i][j - 1].rgbtBlue;
                averageG += image[i][j - 1].rgbtGreen;
                counter++;
            }
            //2
            if (i != (height - 1))
            {
                averageR += image[i + 1][j].rgbtRed;
                averageB += image[i + 1][j].rgbtBlue;
                averageG += image[i + 1][j].rgbtGreen;
                counter++;
            }
            //5
            if (j != (width - 1))
            {
                averageR += image[i][j + 1].rgbtRed;
                averageB += image[i][j + 1].rgbtBlue;
                averageG += image[i][j + 1].rgbtGreen;
                counter++;
            }
            //1
            if ((i != 0) && (j != 0))
            {
                averageR += image[i - 1][j - 1].rgbtRed;
                averageB += image[i - 1][j - 1].rgbtBlue;
                averageG += image[i - 1][j - 1].rgbtGreen;
                counter++;
            }
            //3
            if ((i != 0) && (j != (width - 1)))
            {
                averageR += image[i - 1][j + 1].rgbtRed;
                averageB += image[i - 1][j + 1].rgbtBlue;
                averageG += image[i - 1][j + 1].rgbtGreen;
                counter++;
            }
            //6
            if ((i != (height - 1)) && (j != 0))
            {
                averageR += image[i + 1][j - 1].rgbtRed;
                averageB += image[i + 1][j - 1].rgbtBlue;
                averageG += image[i + 1][j - 1].rgbtGreen;
                counter++;
            }
            //8
            if ((i != (height - 1)) && (j != (width - 1)))
            {
                averageR += image[i + 1][j + 1].rgbtRed;
                averageB += image[i + 1][j + 1].rgbtBlue;
                averageG += image[i + 1][j + 1].rgbtGreen;
                counter++;
            }

            averageR = averageR / counter;
            averageB = averageB / counter;
            averageG = averageG / counter;
            image2[i][j].Red = roundf(averageR);
            image2[i][j].Blue = roundf(averageB);
            image2[i][j].Green = roundf(averageG);
        }
    }
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            image[i][j].rgbtRed = image2[i][j].Red;
            image[i][j].rgbtBlue = image2[i][j].Blue;
            image[i][j].rgbtGreen = image2[i][j].Green;
        }
    }


    return;
}

// Detect edges
void edges(int height, int width, RGBTRIPLE image[height][width])
{
    typedef struct
    {
        int Red;
        int Blue;
        int Green;
    }
    temp;
    temp image2[height][width];

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {


            float ColorRedX = 0;
            float ColorRedY = 0;
            float ColorGreenX = 0;
            float ColorGreenY = 0;
            float ColorBlueX = 0;
            float ColorBlueY = 0;


            if (i != 0)
            {
                ColorRedY += (-2 * image[i - 1][j].rgbtRed);
                ColorBlueY += (-2 * image[i - 1][j].rgbtBlue);
                ColorGreenY += (-2 * image[i - 1][j].rgbtGreen);
            }

            if (j != 0)
            {
                ColorRedX += (-2 * image[i][j - 1].rgbtRed);
                ColorBlueX += (-2 * image[i][j - 1].rgbtBlue);
                ColorGreenX += (-2 * image[i][j - 1].rgbtGreen);
            }

            if (i != (height - 1))
            {
                ColorRedY += (2 * image[i + 1][j].rgbtRed);
                ColorBlueY += (2 * image[i + 1][j].rgbtBlue);
                ColorGreenY += (2 * image[i + 1][j].rgbtGreen);
            }

            if (j != (width - 1))
            {
                ColorRedX += (2 * image[i][j + 1].rgbtRed);
                ColorBlueX += (2 * image[i][j + 1].rgbtBlue);
                ColorGreenX += (2 * image[i][j + 1].rgbtGreen);
            }

            if ((i != 0) && (j != 0))
            {
                ColorRedX += (-1 * image[i - 1][j - 1].rgbtRed);
                ColorBlueX += (-1 * image[i - 1][j - 1].rgbtBlue);
                ColorGreenX += (-1 * image[i - 1][j - 1].rgbtGreen);
                ColorRedY += (-1 * image[i - 1][j - 1].rgbtRed);
                ColorBlueY += (-1 * image[i - 1][j - 1].rgbtBlue);
                ColorGreenY += (-1 * image[i - 1][j - 1].rgbtGreen);
            }

            if ((i != 0) && (j != (width - 1)))
            {
                ColorRedX += image[i - 1][j + 1].rgbtRed;
                ColorBlueX += image[i - 1][j + 1].rgbtBlue;
                ColorGreenX += image[i - 1][j + 1].rgbtGreen;
                ColorRedY += (-1 * image[i - 1][j + 1].rgbtRed);
                ColorBlueY += (-1 * image[i - 1][j + 1].rgbtBlue);
                ColorGreenY += (-1 * image[i - 1][j + 1].rgbtGreen);
            }

            if ((i != (height - 1)) && (j != 0))
            {
                ColorRedX += (-1 * image[i + 1][j - 1].rgbtRed);
                ColorBlueX += (-1 * image[i + 1][j - 1].rgbtBlue);
                ColorGreenX += (-1 * image[i + 1][j - 1].rgbtGreen);
                ColorRedY += image[i + 1][j - 1].rgbtRed;
                ColorBlueY += image[i + 1][j - 1].rgbtBlue;
                ColorGreenY += image[i + 1][j - 1].rgbtGreen;
            }

            if ((i != (height - 1)) && (j != (width - 1)))
            {
                ColorRedX += image[i + 1][j + 1].rgbtRed;
                ColorBlueX += image[i + 1][j + 1].rgbtBlue;
                ColorGreenX += image[i + 1][j + 1].rgbtGreen;
                ColorRedY += image[i + 1][j + 1].rgbtRed;
                ColorBlueY += image[i + 1][j + 1].rgbtBlue;
                ColorGreenY += image[i + 1][j + 1].rgbtGreen;
            }
            float SobelR = sqrt((ColorRedX * ColorRedX) + (ColorRedY * ColorRedY));
            float SobelB = sqrt((ColorBlueX * ColorBlueX) + (ColorBlueY * ColorBlueY));
            float SobelG = sqrt((ColorGreenX * ColorGreenX) + (ColorGreenY * ColorGreenY));
            image2[i][j].Red = round(SobelR);
            image2[i][j].Blue = round(SobelB);
            image2[i][j].Green = round(SobelG);

            if (image2[i][j].Red > 255)
            {
                image2[i][j].Red = 255;
            }
            if (image2[i][j].Blue > 255)
            {
                image2[i][j].Blue = 255;
            }
            if (image2[i][j].Green > 255)
            {
                image2[i][j].Green = 255;
            }
        }
    }


    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            image[i][j].rgbtRed = image2[i][j].Red;
            image[i][j].rgbtBlue = image2[i][j].Blue;
            image[i][j].rgbtGreen = image2[i][j].Green;
        }
    }

    return;
}