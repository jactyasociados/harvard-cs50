#include "helpers.h"
#include <math.h>

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    float GrayColor;

    for (int i = 0; i < width; i++) //loop through colums
    {
        for (int j = 0; j < height; j++) //loop through rows
        {
            // apply average and round value for gray color
            GrayColor = round((image[j][i].rgbtRed + image[j][i].rgbtGreen + image[j][i].rgbtBlue) / 3.000);

            image[j][i].rgbtRed = GrayColor;
            image[j][i].rgbtGreen = GrayColor;
            image[j][i].rgbtBlue = GrayColor;
        }
    }
    return;
}

// Convert image to sepia color
void sepia(int height, int width, RGBTRIPLE image[height][width])
{
    int sepiaRed;
    int sepiaGreen;
    int sepiaBlue;

    for (int i = 0; i < width; i++) //loop through columns
    {
        for (int j = 0; j < height; j++) //loop through rows
        {
            sepiaRed = round(0.393 * image[j][i].rgbtRed + 0.769 * image[j][i].rgbtGreen + 0.189 * image[j][i].rgbtBlue);
            sepiaGreen = round(0.349 * image[j][i].rgbtRed + 0.686 * image[j][i].rgbtGreen + 0.168 * image[j][i].rgbtBlue);
            sepiaBlue = round(0.272 * image[j][i].rgbtRed + 0.534 * image[j][i].rgbtGreen + 0.131 * image[j][i].rgbtBlue);

            if (sepiaRed > 255)
            {
                sepiaRed = 255;
            }

            if (sepiaGreen > 255)
            {
                sepiaGreen = 255;
            }

            if (sepiaBlue > 255)
            {
                sepiaBlue = 255;
            }

            image[j][i].rgbtRed = sepiaRed;
            image[j][i].rgbtGreen = sepiaGreen;
            image[j][i].rgbtBlue = sepiaBlue;
        }
    }
    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    //T̀emporary array to swap colors
    int tmp[3];
    for (int j = 0; j < height; j++) //loop trough rows
    {
        for (int i = 0; i < width / 2; i++) //loop through columns
        {
            tmp[0] = image[j][i].rgbtRed;
            tmp[1] = image[j][i].rgbtGreen;
            tmp[2] = image[j][i].rgbtBlue;

            // swap pixels as a mírror
            image[j][i].rgbtRed = image[j][width - i - 1].rgbtRed;
            image[j][i].rgbtGreen = image[j][width - i - 1].rgbtGreen;
            image[j][i].rgbtBlue = image[j][width - i - 1].rgbtBlue;

            //swap values
            image[j][width - i - 1].rgbtRed = tmp[0];
            image[j][width - i - 1].rgbtGreen = tmp[1];
            image[j][width - i - 1].rgbtBlue = tmp[2];
        }
    }
    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    int ColorRed;
    int ColorGreen;
    int ColorBlue;
    float counter;

    //Temporary table
    RGBTRIPLE tmp[height][width];

    for (int i = 0; i < width; i++) //loop trhough columns
    {
        for (int j = 0; j < height; j++) //loop through rows
        {
            ColorRed = 0;
            ColorGreen = 0;
            ColorBlue = 0;
            counter = 0.00;

            // sums values of the pixel and neighbour ones inside the picture
            for (int h = -1; h < 2; h++) //loop through rows
            {
                if (j + h < 0 || j + h > height - 1)
                {
                    continue;
                }

                for (int c = -1; c < 2; c++) //loop through columns
                {
                    if (i + c < 0 || i + c > width - 1)
                    {
                        continue;
                    }

                    ColorRed += image[j + h][i + c].rgbtRed;
                    ColorGreen += image[j + h][i + c].rgbtGreen;
                    ColorBlue += image[j + h][i + c].rgbtBlue;
                    counter++;
                }
            }

            //average of previous colors to blur image
            tmp[j][i].rgbtRed = round(ColorRed / counter);
            tmp[j][i].rgbtGreen = round(ColorGreen / counter);
            tmp[j][i].rgbtBlue = round(ColorBlue / counter);
        }
    }

    //copy values from temporary table
    for (int i = 0; i < width; i++) //loop through columns
    {
        for (int j = 0; j < height; j++) //loop through rows
        {
            image[j][i].rgbtRed = tmp[j][i].rgbtRed;
            image[j][i].rgbtGreen = tmp[j][i].rgbtGreen;
            image[j][i].rgbtBlue = tmp[j][i].rgbtBlue;
        }
    }
    return;
}