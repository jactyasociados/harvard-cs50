#include <cs50.h>
#include <stdio.h>
#include <math.h>

// asks for card number, checks validity and says the brand
int main(void)
{
    int count;
    long card = 0;
    int brand = 0;

    // Promt for the card number
    card = get_long("Card number: ");
    long temp = card;
    count = 0;
    // counts number of digits
    while (temp > 0)
    {
        count++;
        temp /= 10;
    }
    // Check if number of card digits is valid
    if (count == 13)
    {
        int Visa = card / 1000000000000;
        if (Visa == 4)
        {
            brand = 1;
        }
    }
    else if (count == 15)
    {
        int Amex = card / 10000000000000;
        if (Amex == 34 || Amex == 37)
        {
            brand = 2;
        }
    }
    else if (count == 16)
    {
        int MasterCard = card / 100000000000000;
        int Visa_16_digits = card / 1000000000000000;
        if (MasterCard == 51 || MasterCard == 52 || MasterCard == 53 || MasterCard == 54 || MasterCard == 55)
        {
            brand = 3;
        }
        else if (Visa_16_digits == 4)
        {
            brand = 1;
        }
    }

    // if the number of digits is correct it now checks that luhn's Algorithm is respected, otherwise returns INVALID
    if (brand != 0)
    {
        int tmpn;
        int last = 0;
        int Sec_to_last = 0;

        // it picks odd and even numbers starting from the end and sums them
        while (card > 0)
        {
            last += card % 10;

            // eliminates last digit so we can access the first even number from the end
            card /= 10;

            // as for the algorithm we take the even number * 2
            tmpn = (card % 10) * 2;

            // if the even number * 2 is 10 or bigger adds the rest of digits that are odds
            if (tmpn > 9)
            {
                Sec_to_last += tmpn % 10 + tmpn / 10;
            }
            // if the even number * 2 is 9 or less it just adds it to the others
            else
            {
                Sec_to_last += tmpn;
            }

            // eliminates last digit to get odd numbers
            card /= 10;
        }
        // validates the Algorithm and then prints the brand
        if ((last + Sec_to_last) % 10 == 0)
        {
            switch (brand)
            {
                case 1:
                    printf("VISA\n");
                    break;
                case 2:
                    printf("AMEX\n");
                    break;
                case 3:
                    printf("MASTERCARD\n");
                    break;
            }
        }
        // if it is not valid card prints invalid
        else
        {
            printf("INVALID\n");
        }
    }
    // prints invalid if the digits number was not correct in the first place
    else
    {
        printf("INVALID\n");
    }
}
