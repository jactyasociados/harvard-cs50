// Implements a dictionary's functionality

#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <strings.h>


#include "dictionary.h"

//Node in a hash table
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;
}
node;

//Number of buckets in hash table
const unsigned int N = 26;

//Hash table
node *table[N];
int totalWords = 0;

//check if word is in dictionary, return false elsewere
bool check(const char *word)
{
    node *cursor = table[hash(word)];

    //compare words case insensitive
    if (strcasecmp(cursor->word, word) == 0)
    {
        return true;
    }

    //keep traversing linked list until it finds the word or finish
    while (cursor->next != NULL)
    {
        cursor = cursor->next;
        if (strcasecmp(cursor->word, word) == 0)
        {
            return true;
        }
    }

    return false;
}

//Hashes word to an integer
//Used one bucket 0 to 25 representing the letters of the alphabet in loware case
unsigned int hash(const char *word)
{
    int n = (int) tolower(word[0]) - (int)'a';
    return n;
}

// Loads dictionary into memory, returning true if successful else false
bool load(const char *dictionary)
{
    // opens the dictionary and initializes temporary space to hold the words
    FILE *file = fopen(dictionary, "r");
    char *Word = malloc(LENGTH + 1);
    if (Word == NULL)
    {
        return false;
    }

    // reads file until the end
    while (fscanf(file, "%s", Word) != EOF)
    {
        // allocates memory for a node in which the word will be inserted
        node *n = malloc(sizeof(node));
        if (n == NULL)
        {
            return false;
        }

        // copies the word in the chunk of memory allocated and then updates the words count
        strcpy(n->word, Word);
        totalWords++;

        // set next to point at beginning of list
        n->next = table[hash(Word)];

        // set array to point at n which becomes new beginning of the list
        table[hash(Word)] = n;
    }

    fclose(file);
    free(Word);
    return true;
}

// Returns number of words in dictionary if loaded else 0 if not yet loaded
unsigned int size(void)
{
    return totalWords;
}

//Unloads dictionary from memory, returning true if successful else false
bool unload(void)
{
    // creates two pointers to traverse the linked list and cancel its element without losing its address
    node *tmp;
    node *cursor;

    // repeats for every index in the table
    for (int i = 0; i < N; i++)
    {
        if (table[i] == NULL)
        {
            continue;
        }

        cursor = table[i];
        tmp = cursor;

        // until the end of the list keeps freeing the memory allocated in load
        while (cursor->next != NULL)
        {
            cursor = cursor->next;
            free(tmp);
            tmp = cursor;
        }
        free(cursor);
    }
    return true;
}
